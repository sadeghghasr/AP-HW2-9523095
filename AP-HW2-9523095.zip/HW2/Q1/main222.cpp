#include<iostream>
#include "map.h"

int main()
{
	int w{};
	std::cin>>w;
	Map map1{w};
	map1.showMap();
	std::cout << std::endl << std::endl;
	std::cout << "Distance : " << map1.findRoute() << std::endl;
	std::cout << std::endl;
	std::cout << "Route : " << std::endl;
	map1.showRoute();
	std::cout << std::endl << std::endl;
	std::cout << "Distance : " << map1.findRoute2() <<std::endl;
	std::cout << std::endl;
	std::cout << "Route : " << std::endl;
	map1.showRoute();
	map1.bestRoute();
	
	return 0;
}
