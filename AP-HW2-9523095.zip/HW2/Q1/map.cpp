#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <math.h>
#include <cmath>
#include <string>
#include <vector>
#include <bitset>
#include "map.h"


Map::Map(int a)//generate map with random number
{
	n=a;
	arr=new int* [n];
	for (int i{};i<n;i++)
	{
		arr[i]=new int [n];
	}
	for (int i{};i<n;i++)
	{
		for(int j{};j<n;j++)
		{
			arr[i][j] = rand() % 100;	
		}
	}
	

}
//showing map that generated in Map
void Map::showMap(){
	for(int i{};i < n;i++)
	{
		for(int j{};j<n;j++)
		{
			std::cout<<std::setw(4) <<arr[i][j];
		}
		std::cout<<std::endl;
	}
}
int Map::findRoute()//find route part a
{
	int i{};

	arr2 = new char* [n];//Hilighting route
	for (int i{}; i<n ;i++)
	{
		arr2[i]=new char [n];
	}
	for (int i{}; i<n ; i++)
	{
		for(int j{};j<n;j++)
		{
			arr2[i][j] ='-';	
		}
	}

	for(int j{};j<n;j++)//find route with diff 
		{

			if(i!= n-1 && j != n-1)
			{
				int y{std::abs(arr[i][j]-arr[i][j+1])};
				int z{std::abs(arr[i][j]-arr[i+1][j])};
				if (y > z)
				{
					arr2[i+1][j] = '*';
					i++;
					j--;
					diff=diff+z;
					
				}
				else
				{
					arr2[i][j+1] = '*';
					diff=diff+y;
				
				}
			}
			
			if (i==n-1)
			{
				for(int o{n-1} ; o > j+1 ; o--)
				{	
					arr2[i][o]='*';
					diff = diff + std::abs(arr[i][o]-arr[i][o -1]);
				}

				break;
			}
			if (j==n-1)
			{
				if(i==n-1)
					diff=diff+ std::abs(arr[n-1][n-1] - arr[n-2][n-1]);
				for(int o{n-1} ; o>i ; o--)
				{
					arr2[o][j]='*';
					diff = diff + std::abs(arr[o][j]-arr[o-1][j]);
				}
				break;
			}
			
		}
		arr2[0][0] = '*';
		return diff;
}

int Map::findRoute2()//find route part b 
{
	int i{};
	diff = 0;
	arr2 = new char* [n];//Hilighting route
	for (int i{}; i<n ;i++)
	{
		arr2[i]=new char [n];
	}
	for (int i{}; i<n ; i++)
	{
		for(int j{};j<n;j++)
		{
			arr2[i][j] ='-';	
		}
	}

	for(int j{};j<n;j++)
		{
			if (i== 0 && j== 0)
				arr2[i][j] = '*';

			if(i!= n-1 && j != n-1)
			{
				int y{std::abs(arr[i][j]- arr[i][j+1])};
				int z{std::abs(arr[i][j]- arr[i+1][j])};
				int w{std::abs(arr[i][j]- arr[i+1][j+1])};
				if (y > z && w > z)
				{
					arr2[i+1][j] = '*';
					i++;
					j--;
					diff=diff+z;
					
				}
				if ((z > y && w > y) || y == z)
				{
					arr2[i][j+1] = '*';
					diff=diff+y;
				
				}
				if ((w<z && w<y) || w == z || w == y || ( w == z && w == y))
				{
					arr2[i+1][j+1]='*';
					diff=diff+w;
					i++;
				}
			}
			
			if (i==n-1)
			{
				for(int o{n-1} ; o > j + 1 ; o--)
				{	
					arr2[i][o]='*';
					diff = diff + std::abs(arr[i][o]-arr[i][o -1]);
				}

				break;
			}
			if (j==n-1)
			{
				if(i==n-1)
					diff=diff+ std::abs(arr[n-1][n-1] - arr[n-2][n-1]);
				for(int o{n-1} ; o>i ; o--)
				{
					arr2[o][j]='*';
					diff = diff + std::abs(arr[o][j]-arr[o-1][j]);
				}
				break;
			}
			
		}

		return diff;

}


int Map::findRoute3()//find route for part c
{
	int i{};

	arr2 = new char* [n];//high lighting route
	for (int i{}; i<n ;i++)
	{
		arr2[i]=new char [n];
	}
	for (int i{}; i<n ; i++)
	{
		for(int j{};j<n;j++)
		{
			arr2[i][j] ='-';	
		}
	}

	for(int j{};j<n;j++)
		{

			if(i!= n-1 && j != n-1)
			{
				int y{std::abs(arr[i][j]- arr[i][j+1])};
				int z{std::abs(arr[i][j]- arr[i+1][j])};
				int w{std::abs(arr[i][j]- arr[i+1][j+1])};
				if (y > z && w > z)
				{
					arr2[i+1][j] = '*';
					i++;
					j--;
					diff=diff+z;
					
				}
				if (z > y && w > y)
				{
					arr2[i][j+1] = '*';
					diff=diff+y;
				
				}
				if (w<z && w<y)
				{
					arr2[i+1][j+1]='*';
					diff=diff+w;
					i++;
				}
			}
			
			if (i==n-1)
			{
				for(int o{n-1} ; o>j ; o--)
				{	
					arr2[i][o]='*';
					diff = diff + std::abs(arr[i][o]-arr[i][o]);
				}

				break;
			}
			if (j==n-1)
			{
				if(i==n-1)
					diff=diff+ std::abs(arr[n-1][n-1] - arr[n-2][n-1]);
				for(int o{n-1} ; o>i ; o--)
				{
					arr2[o][j]='*';
					diff = diff + std::abs(arr[o][j]-arr[o-1][j]);
				}
				break;
			}
			if (i== 0 && j== 0)
				arr2[i][j] = '*';
		}

		return diff;

}


void Map::showRoute()
{
	for(int m{};m < n;m++)
	{
		for(int w{};w<n;w++)
		{
			std::cout<<std::setw(4) <<arr2[m][w];
		}
		std::cout<<std::endl;
	}
	
}

void Map::bestRoute ()
{
	int q{2 * n - 2}; // number of moves.
	std::string binary{} , path{};
	std::vector <std::string> v{}; //vector of paths;
	std::vector <int> Vec_of_diff2{};
	
		for(long int i{};i< std::pow(2 , q);i++)
		 	{
			 	int right{} , down{};//to go right and down.
			 	binary = std::bitset< 100 >(i).to_string();
			 	path = binary.substr(100 - q,100);
			 	for(int j{};j < q;j++)
			 		{
						if(path[j] == '1')
						{
		 					right++;
		 					path[j] = 'r';
						}
		 				else
		 				{
		 					down++;
		 					path[j] = 'd';
		 				}
		 			}
		 		if (right == down)	
		 		{ 	
		 			v.push_back(path);
		 		}
			}
	
		for(size_t i{}; i < v.size() ; i++)
			{
				std::vector <int> amount_of_path{}; 
				int r{0} , d{0};
				for (int i{}; i<n ; i++)
					{
					for(int j{};j<n;j++)
					{
						arr2[i][j] ='-';	
					}
					} //get initial amount to arr2[]
				arr2[0][0] = '*';
				amount_of_path.push_back(arr[0][0]);
				
				for(size_t j{}; j<v[i].size();j++)
					{
						if(v[i][j] == 'r')
							r++;
						if(v[i][j] == 'd')
							d++;
						arr2[d][r] = '*';
						amount_of_path.push_back(arr[d][r]);

					}
		
				diff2 = 0;

				for(size_t j{1} ; j < amount_of_path.size(); j++)
					{
						diff2 += std::abs(amount_of_path[j] - amount_of_path[j-1]);
					}

				Vec_of_diff2.push_back(diff2);
			}

			int location{};
			int minimum{Vec_of_diff2[0]};
			for(size_t c{1}; c < Vec_of_diff2.size();c++)
			{
				if (Vec_of_diff2[c] < minimum)
				{
					minimum = Vec_of_diff2[c];
					location = c;
				}
			}

			std::cout << v[location] << " --> and the minimum distance is : " <<Vec_of_diff2[location]<<std::endl;
			for (int i{}; i<n ; i++)
				{
					for(int j{};j<n;j++)
					{
						arr2[i][j] ='-';	
					}
				} 
			arr2[0][0] = '*';

				int r{0} , d{0};

			for(size_t j{}; j<v[location].size();j++)
					{
						if(v[location][j] == 'r')
							r++;
						if(v[location][j] == 'd')
							d++;
						arr2[d][r] = '*';

					}
				for(int m{};m < n;m++)		//showing the arr2;
					{
					for(int w{};w<n;w++)
					{
						std::cout<<std::setw(4) <<arr2[m][w];
					}
					std::cout<<std::endl;	
					}
}


Map::~Map()//distructor
{
	for (int i{};i<n;i++)
		delete[] arr[i];
	delete[] arr;

	for (int i{};i<n;i++)
		delete[] arr2[i];
	delete[] arr2;	
	
}
