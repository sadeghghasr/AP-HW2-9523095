#ifndef MAP_H
#define MAP_H
#include <vector>
#include <string>

class Map{
public:
	Map(int);

	int n{};

	
	void showMap();//show map that created by random
	int findRoute();//find route foe part a
	int findRoute2();//find route for part b
	int findRoute3();//find route for part c
	void showRoute();//showing route for each route
	void bestRoute();//part c
	
	~Map();

private:
	int** arr {};
	char** arr2{};
	int** arr3{};
	int diff{};
	int diff2{};

	void disp(std::vector <std::string> v);
};
#endif