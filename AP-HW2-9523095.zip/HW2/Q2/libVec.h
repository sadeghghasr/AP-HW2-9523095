#ifndef LIBVEC_H
#define LIBVEC_H
#include<vector>

class libVec{
public:
libVec()=default;//default constructor
long int counter(long int);//counter & sum
std::vector<long int> vec;
long int S;
long int sum{};
};
#endif