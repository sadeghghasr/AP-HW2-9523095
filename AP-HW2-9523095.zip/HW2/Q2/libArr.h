#ifndef LIBARR_H
#define LIBARR_H
#include<iostream>

class libArr{
public:
	libArr()=default;//default constructor
	long int counter(long int);//counter & sum
	long int sum{};//for suming
	int S{};
	


};
#endif