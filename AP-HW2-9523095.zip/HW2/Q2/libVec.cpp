#include"libVec.h"
#include<iostream>
#include<vector>


long int libVec::counter(long int n)//define counter function
{
	long int primary{};
	S=n;
	std::vector<long int> vec;
	sum=primary;//for suming
	for(long int i{};i < S;i++)
	{
		vec.push_back(i);
		sum+=vec[i];
	}
	return sum;
}
