#include"libArr.h"
#include<iostream>



long int libArr::counter(long int n)//define counter function
{
	long int temp{};
	S=n;
	int arr[S];//array
	sum=temp;
	for(long int i{};i < S;i++)
	{
		arr[i]=i;
		sum+=arr[i];
	}
	return sum;
}

