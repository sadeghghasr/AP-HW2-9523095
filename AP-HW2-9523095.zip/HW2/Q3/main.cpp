#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include<sstream>


int main()
{
	std::ifstream is{"db.txt"};//read from file
	std::string s{};
	std::vector<std::string> vec;
	while(std::getline( is , s))//get line to line from file
	{
    std::cout << s << std::endl;
		vec.push_back(s);
 	}
    std::vector<std::string> ss1;//Date
    std::vector<int> ss3;//P.id
    std::vector<int> ss4;//C.id
    std::string s1{},s2{};
    int s3{},s4{};
    for(size_t i{};i < vec.size();i++)
    {
    	std::istringstream iss{vec[i]};
    	iss >> s1 >> s2 >> s3 >> s4;
    	ss1.push_back(s1);
    	ss3.push_back(s3);
    	ss4.push_back(s4);
    }
   
   std::vector<int> sep;//seperator
   sep.push_back(0);
  for(size_t i{};i < ss1.size();i++)
   {
   		if(ss1[i+1].compare(ss1[i]))
   		{
   			if(i == ss1.size()-1)
   				sep.push_back(i);
   			else
   			sep.push_back(i+1);
   		}

   }
   for(size_t i{};i< sep.size();i++)
   {
   	std::cout << sep[i] << std::endl;
   }
  std::vector<std::vector<int>> cp;//class of product
  std::vector<std::vector<int>> cc;//class of customer
 	for(size_t j{};j < sep.size()-1;j++)
 	{
  int c{sep[j+1]-sep[j]};
  int d{sep[j+1]-sep[j]};
  std::vector<int> row(c);
  std::vector<int> row2(d);
 	for(int i=sep[j];i < sep[j+1];i++)
 	{
    row[--c]=ss3[i];
    row2[--d]=ss4[i];
  }
  cp.push_back(row);
  cc.push_back(row2);
   		
 	}
 for(size_t i{};i < cp.size();i++)//sorting vector about product
  {
    for(size_t j{};j < cp[i].size()-1;j++)
    {
      double temp{};
      if (cp[i][j] > cp[i][j+1])
      {
      temp = cp[i][j+1];
      cp[i][j+1] = cp[i][j];
      cp[i][j] = temp;
    }
  }
}
for(size_t i{};i < cc.size();i++)//sorting vector about customer
  {
    for(size_t j{};j < cc[i].size()-1;j++)
    {
      double temp{};
      if (cc[i][j] > cc[i][j+1])
      {
      temp = cc[i][j+1];
      cc[i][j+1] = cc[i][j];
      cc[i][j] = temp;
    }
  }
}
std::cout << std::endl;
std::ofstream out{"dbnew.txt"};//output file
int cnt{};
int cnt1{};
 for(size_t i{};i < cp.size();i++)
  {
    int temp{1};
    cnt=temp;
    cnt1=temp;
    out << ss1[sep[i]] << "] ";
    for(size_t j{};j < cp[i].size()-1;j++)
    {
      if(!(cp[i][j+1]==(cp[i][j])))
      {
        cnt++;
      }
      if(!(cc[i][j+1]==(cc[i][j])))
      {
        cnt1++;
      }
    }
    out << cnt << " " << cnt1 << std::endl;
  }
  
	return 0;

}
